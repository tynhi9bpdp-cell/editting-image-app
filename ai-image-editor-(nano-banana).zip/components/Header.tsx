
import React from 'react';

const Header: React.FC = () => {
    return (
        <header className="bg-brand-surface p-4 shadow-md">
            <div className="max-w-7xl mx-auto text-center">
                <h1 className="text-3xl font-extrabold text-white tracking-tight">
                    <span className="bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-teal-300">
                        AI Image Editor
                    </span>
                </h1>
                <p className="mt-1 text-sm text-brand-text-secondary">
                    Powered by Gemini Nano Banana (gemini-2.5-flash-image-preview)
                </p>
            </div>
        </header>
    );
};

export default Header;
