import React, { useRef } from 'react';
import { UploadIcon } from './icons';

interface ImageUploaderProps {
    onImagesChange: (files: FileList) => void;
}

const ImageUploader: React.FC<ImageUploaderProps> = ({ onImagesChange }) => {
    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const files = event.target.files;
        if (files && files.length > 0) {
            onImagesChange(files);
        }
        // Reset the input value to allow uploading the same file again
        if(event.target) {
            event.target.value = '';
        }
    };

    const handleClick = () => {
        fileInputRef.current?.click();
    };

    return (
        <div 
            className="w-full p-4 border-2 border-dashed border-brand-secondary rounded-lg text-center cursor-pointer hover:border-brand-primary transition-colors duration-300"
            onClick={handleClick}
        >
            <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileChange}
                className="hidden"
                accept="image/png, image/jpeg, image/webp"
                multiple
            />
            <div className="flex flex-col items-center justify-center text-brand-text-secondary">
                <UploadIcon className="w-12 h-12 mb-2" />
                <p className="font-semibold">Click to upload images</p>
                <p className="text-xs">PNG, JPG, or WEBP</p>
            </div>
        </div>
    );
};

export default ImageUploader;