
export const fileToBase64 = (file: File): Promise<{ mimeType: string; data: string }> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      const mimeType = file.type;
      const base64Data = result.split(',')[1];
      
      if (mimeType && base64Data) {
        resolve({ mimeType, data: base64Data });
      } else {
        reject(new Error("Failed to read file or determine MIME type."));
      }
    };
    reader.onerror = (error) => reject(error);
    reader.readAsDataURL(file);
  });
};
