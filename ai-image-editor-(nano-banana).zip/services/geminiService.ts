import { GoogleGenAI, Modality, Part, Content } from "@google/genai";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
    throw new Error("API_KEY environment variable is not set.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

interface EditImageResult {
    imageData: string | null;
    mimeType: string | null;
    textData: string;
}

interface ImageInput {
    mimeType: string;
    data: string;
}

export const editImage = async (
    images: ImageInput[],
    prompt: string
): Promise<EditImageResult> => {
    try {
        if (images.length === 0) {
            throw new Error("No images provided for editing.");
        }

        // Create an array of image parts
        const imageParts: Part[] = images.map(image => ({
            inlineData: {
                data: image.data,
                mimeType: image.mimeType,
            },
        }));
        
        // Create the text part
        const textPart: Part = { text: prompt };

        // THE CORRECT STRUCTURE: A single Content object containing all parts.
        // This is the definitive fix for the API call failure. The previous structure
        // (an array of Content objects) was incorrect for a single generateContent call
        // and was the root cause of the error.
        const contents: Content = { parts: [...imageParts, textPart] };

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash-image-preview',
            contents: contents, // Pass the single Content object
            config: {
                responseModalities: [Modality.IMAGE, Modality.TEXT],
            },
        });

        let imageData: string | null = null;
        let imageMimeType: string | null = null;
        let textData: string = "";

        if (response.candidates && response.candidates.length > 0) {
            for (const part of response.candidates[0].content.parts) {
                if (part.text) {
                    textData += part.text;
                } else if (part.inlineData) {
                    imageData = part.inlineData.data;
                    imageMimeType = part.inlineData.mimeType;
                }
            }
        }
        
        if (!imageData && !textData) {
            textData = "The model did not return an image or text. Please try again.";
        }

        return { imageData, mimeType: imageMimeType, textData };

    } catch (error) {
        console.error("Error calling Gemini API:", error);
        throw new Error("Failed to generate image edit. Please check your prompt or try again later.");
    }
};
